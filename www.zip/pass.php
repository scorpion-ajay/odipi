<?php
$servername = "localhost";
$username = "root";
$password = "abc123";
$dbname = "odp";
?>